/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "event_groups.h"

#include "adc.h"
#include "gpio.h"
#include "uart0.h"
#include "common_macros.h"
#include "LM35/lm35.h"

#define DRIVER_EVENT_BIT_BUTTON_PRESSED_OFF         (1 << 0)
#define DRIVER_EVENT_BIT_BUTTON_PRESSED_LOW         (1 << 1)
#define DRIVER_EVENT_BIT_BUTTON_PRESSED_MEDIUM      (1 << 2)
#define DRIVER_EVENT_BIT_BUTTON_PRESSED_HIGHT       (1 << 3)


#define PASSENGER_EVENT_BIT_BUTTON_PRESSED_OFF      (1 << 4)
#define PASSENGER_EVENT_BIT_BUTTON_PRESSED_LOW      (1 << 5)
#define PASSENGER_EVENT_BIT_BUTTON_PRESSED_MEDIUM   (1 << 6)
#define PASSENGER_EVENT_BIT_BUTTON_PRESSED_HIGHT    (1 << 7)

#define LOW_DESIRED_TEMP    25
#define MEDIUM_DESIRED_TEMP 30
#define HIGHT_DESIRED_TEMP  35

void Hardware_init();

EventGroupHandle_t xEventGroup = NULL;
SemaphoreHandle_t Mutex = NULL;

uint8 DriverSeatTemperature;
uint8 PassengerSeatTemperature;

void PassengerButtonHandler(void *pvParameters)
{
    TickType_t xLastWakeTime = xTaskGetTickCount();
    int state;
    static int cnt=0;
    static int DriverButtonState=0;
    while (1)
    {

        state = GPIO_PassengerSW2GetState();
        if(state != DriverButtonState){
            DriverButtonState = state;
            if(DriverButtonState == PRESSED){
                cnt++;
                cnt %= 4;

                EventBits_t uxBits;
                uxBits = xEventGroupClearBits(
                        xEventGroup,  /* The event group being updated. */
                                0xff ); /* The bits being cleared. */

                GPIO_PassengerBlueLedOff();
                GPIO_PassengerGreenLedOff();
                GPIO_PassengerRedLedOff();




                if(cnt==1)  xEventGroupSetBits(xEventGroup, PASSENGER_EVENT_BIT_BUTTON_PRESSED_LOW);
                else if(cnt==2) xEventGroupSetBits(xEventGroup, PASSENGER_EVENT_BIT_BUTTON_PRESSED_MEDIUM);
                else if(cnt==3) xEventGroupSetBits(xEventGroup, PASSENGER_EVENT_BIT_BUTTON_PRESSED_HIGHT);

                xSemaphoreTake(Mutex, portMAX_DELAY);

                UART0_SendString("Passenger mode is ");
                if(cnt==0)          UART0_SendString("Off\n");
                else if(cnt==1)     UART0_SendString("LOW\n");
                else if(cnt==2)     UART0_SendString("MED\n");
                else if(cnt==3)     UART0_SendString("HIGH\n");
                xSemaphoreGive(Mutex);
            }
        }
        vTaskDelayUntil(&xLastWakeTime, (100/portTICK_PERIOD_MS));
    }
}
void DriverButtonHandle(void *pvParameters){
    TickType_t xLastWakeTime = xTaskGetTickCount();
    int state;
    static int cnt=0;
    static int DriverButtonState=0;
    for(;;){
        state = GPIO_DriverSW1GetState();
        if(state != DriverButtonState){
            DriverButtonState = state;
            if(DriverButtonState == PRESSED){
                cnt++;
                cnt %= 4;
                EventBits_t uxBits;
                uxBits = xEventGroupClearBits(
                        xEventGroup,  /* The event group being updated. */
                                0xff ); /* The bits being cleared. */


                GPIO_DriverBlueLedOff();
                GPIO_DriverGreenLedOff();
                GPIO_DriverRedLedOff();

                if(cnt==1)  xEventGroupSetBits(xEventGroup, DRIVER_EVENT_BIT_BUTTON_PRESSED_LOW);
                else if(cnt==2) xEventGroupSetBits(xEventGroup, DRIVER_EVENT_BIT_BUTTON_PRESSED_MEDIUM);
                else if(cnt==3) xEventGroupSetBits(xEventGroup, DRIVER_EVENT_BIT_BUTTON_PRESSED_HIGHT);


                xSemaphoreTake(Mutex, portMAX_DELAY);
                UART0_SendString("Driver mode is ");
                if(cnt==0)          UART0_SendString("Off\n");
                else if(cnt==1)     UART0_SendString("LOW\n");
                else if(cnt==2)     UART0_SendString("MED\n");
                else if(cnt==3)     UART0_SendString("HIGH\n");
                xSemaphoreGive(Mutex);
            }
        }
        vTaskDelayUntil(&xLastWakeTime, (100/portTICK_PERIOD_MS));
    }
}
void Temperature_Task(void *pvParameters){
    TickType_t xLastWakeTime = xTaskGetTickCount();
    for(;;){
        DriverSeatTemperature=lm35_get_temperature_PB4();
        if(DriverSeatTemperature<5 || DriverSeatTemperature>40){
            GPIO_DriverRedLedOn();
        }else {
            GPIO_DriverRedLedOff();
        }
        PassengerSeatTemperature =lm35_get_temperature_PB5();
        if(PassengerSeatTemperature<5 || PassengerSeatTemperature>40){
            GPIO_PassengerRedLedOn();
        }else {
            GPIO_PassengerRedLedOff();
        }

        xSemaphoreTake(Mutex, portMAX_DELAY);
        UART0_SendString("Driver Temp is ");
        UART0_SendInteger(DriverSeatTemperature);
        UART0_SendString("\nPassenger Temp is ");
        UART0_SendInteger(PassengerSeatTemperature);
        UART0_SendByte('\n');
        xSemaphoreGive(Mutex);

        vTaskDelayUntil(&xLastWakeTime, (100/portTICK_PERIOD_MS));
    }
}
void Heating_level_LOW(void *pvParameters){
    EventBits_t uxBits;
    for(;;){
        uxBits = xEventGroupWaitBits(
                            xEventGroup,
                            DRIVER_EVENT_BIT_BUTTON_PRESSED_LOW|PASSENGER_EVENT_BIT_BUTTON_PRESSED_LOW,
                            pdFALSE,               // Clear the bits before returning.
                            pdFALSE,
                            portMAX_DELAY );
        if((uxBits & DRIVER_EVENT_BIT_BUTTON_PRESSED_LOW) && LOW_DESIRED_TEMP - DriverSeatTemperature >= 2){
            if(LOW_DESIRED_TEMP - DriverSeatTemperature<5){
                GPIO_DriverGreenLedOn();
                GPIO_DriverRedLedOn();
            }
            else if(LOW_DESIRED_TEMP - DriverSeatTemperature<10){
                GPIO_DriverBlueLedOn();
            }
            else{
                GPIO_DriverGreenLedOn();
            }

            xSemaphoreTake(Mutex, portMAX_DELAY);
            if(LOW_DESIRED_TEMP - DriverSeatTemperature<5){
                UART0_SendString("DRIVER LOW intensity\n");
            }
            else if(LOW_DESIRED_TEMP - DriverSeatTemperature<10){
                UART0_SendString("DRIVER MED intensity\n");
            }
            else{
                UART0_SendString("DRIVER HIGH intensity\n");
            }
            xSemaphoreGive(Mutex);
        }
        if((uxBits & PASSENGER_EVENT_BIT_BUTTON_PRESSED_LOW) && LOW_DESIRED_TEMP - PassengerSeatTemperature >= 2){
            if(LOW_DESIRED_TEMP - PassengerSeatTemperature<5){
                GPIO_PassengerGreenLedOn();
                GPIO_PassengerRedLedOn();
            }
            else if(LOW_DESIRED_TEMP - PassengerSeatTemperature<10)
                GPIO_PassengerBlueLedOn();
            else
                GPIO_PassengerGreenLedOn();

            xSemaphoreTake(Mutex, portMAX_DELAY);
            if(LOW_DESIRED_TEMP - DriverSeatTemperature<5){
                UART0_SendString("PASSENGER LOW intensity\n");
            }
            else if(LOW_DESIRED_TEMP - DriverSeatTemperature<10){
                UART0_SendString("PASSENGER MED intensity\n");
            }
            else{
                UART0_SendString("PASSENGER HIGH intensity\n");
            }
            xSemaphoreGive(Mutex);
        }


        //another block for passenger
    }
}
void Heating_level_MEDUIM(void *pvParameters){
    EventBits_t uxBits;
    for(;;){
        uxBits = xEventGroupWaitBits(
                            xEventGroup,
                            DRIVER_EVENT_BIT_BUTTON_PRESSED_MEDIUM | PASSENGER_EVENT_BIT_BUTTON_PRESSED_MEDIUM,
                            pdFALSE,               // Clear the bits before returning.
                            pdFALSE,
                            portMAX_DELAY );
        if((uxBits & DRIVER_EVENT_BIT_BUTTON_PRESSED_MEDIUM) && MEDIUM_DESIRED_TEMP - DriverSeatTemperature >= 2){
            if(MEDIUM_DESIRED_TEMP - DriverSeatTemperature<5){
                GPIO_DriverGreenLedOn();
                GPIO_DriverRedLedOn();
            }
            else if(MEDIUM_DESIRED_TEMP - DriverSeatTemperature<10)
                GPIO_DriverBlueLedOn();
            else
                GPIO_DriverGreenLedOn();


            xSemaphoreTake(Mutex, portMAX_DELAY);
            if(LOW_DESIRED_TEMP - DriverSeatTemperature<5){
                UART0_SendString("DRIVER LOW intensity\n");
            }
            else if(LOW_DESIRED_TEMP - DriverSeatTemperature<10){
                UART0_SendString("DRIVER MED intensity\n");
            }
            else{
                UART0_SendString("DRIVER HIGH intensity\n");
            }
            xSemaphoreGive(Mutex);
        }

        //another block for passenger
        if((uxBits & PASSENGER_EVENT_BIT_BUTTON_PRESSED_MEDIUM) && MEDIUM_DESIRED_TEMP - PassengerSeatTemperature >= 2){
            if(MEDIUM_DESIRED_TEMP - PassengerSeatTemperature<5){
                GPIO_PassengerGreenLedOn();
                GPIO_PassengerRedLedOn();
            }
            else if(MEDIUM_DESIRED_TEMP - PassengerSeatTemperature<10)
                GPIO_PassengerBlueLedOn();
            else
                GPIO_PassengerGreenLedOn();

            xSemaphoreTake(Mutex, portMAX_DELAY);
            if(LOW_DESIRED_TEMP - DriverSeatTemperature<5){
                UART0_SendString("PASSENGER LOW intensity\n");
            }
            else if(LOW_DESIRED_TEMP - DriverSeatTemperature<10){
                UART0_SendString("PASSENGER MED intensity\n");
            }
            else{
                UART0_SendString("PASSENGER HIGH intensity\n");
            }
            xSemaphoreGive(Mutex);
        }
    }
}
void Heating_level_HIGH(void *pvParameters){
    EventBits_t uxBits;
    for(;;){
        uxBits = xEventGroupWaitBits(
                            xEventGroup,
                            DRIVER_EVENT_BIT_BUTTON_PRESSED_HIGHT | PASSENGER_EVENT_BIT_BUTTON_PRESSED_HIGHT,
                            pdFALSE,               // Clear the bits before returning.
                            pdFALSE,
                            portMAX_DELAY );
        if((uxBits & DRIVER_EVENT_BIT_BUTTON_PRESSED_HIGHT) && HIGHT_DESIRED_TEMP - DriverSeatTemperature >= 2){
            if(HIGHT_DESIRED_TEMP - DriverSeatTemperature<5){
                GPIO_DriverGreenLedOn();
                GPIO_DriverRedLedOn();
            }
            else if(HIGHT_DESIRED_TEMP - DriverSeatTemperature<10)
                GPIO_DriverBlueLedOn();
            else
                GPIO_DriverGreenLedOn();

            xSemaphoreTake(Mutex, portMAX_DELAY);
            if(LOW_DESIRED_TEMP - DriverSeatTemperature<5){
                UART0_SendString("DRIVER LOW intensity\n");
            }
            else if(LOW_DESIRED_TEMP - DriverSeatTemperature<10){
                UART0_SendString("DRIVER MED intensity\n");
            }
            else{
                UART0_SendString("DRIVER HIGH intensity\n");
            }
            xSemaphoreGive(Mutex);
        }

        if((uxBits & PASSENGER_EVENT_BIT_BUTTON_PRESSED_HIGHT) && HIGHT_DESIRED_TEMP - PassengerSeatTemperature >= 2){
            if(HIGHT_DESIRED_TEMP - PassengerSeatTemperature<5){
                GPIO_PassengerGreenLedOn();
                GPIO_PassengerRedLedOn();
            }
            else if(HIGHT_DESIRED_TEMP - PassengerSeatTemperature<10)
                GPIO_PassengerBlueLedOn();
            else
                GPIO_PassengerGreenLedOn();


            xSemaphoreTake(Mutex, portMAX_DELAY);
            if(LOW_DESIRED_TEMP - DriverSeatTemperature<5){
                UART0_SendString("PASSENGER LOW intensity\n");
            }
            else if(LOW_DESIRED_TEMP - DriverSeatTemperature<10){
                UART0_SendString("PASSENGER MED intensity\n");
            }
            else{
                UART0_SendString("PASSENGER HIGH intensity\n");
            }
            xSemaphoreGive(Mutex);
        }
        //another block for passenger
    }
}
uint32 ullTasksOutTime[7];
uint32 ullTasksInTime[7];
uint32 ullTasksTotalTime[7];

void vRunTimeMeasurementsTask(void *pvParameters){
    TickType_t xLastWakeTime = xTaskGetTickCount();
    for(;;){
        uint8 ucCounter, ucCPU_Load;
        int ullTotalTasksTime = 0;

        for(ucCounter = 1; ucCounter <= 6; ucCounter++)
        {
            ullTotalTasksTime += ullTasksTotalTime[ucCounter];
        }
        ucCPU_Load = (ullTotalTasksTime * 100) /  GPTM_WTimer0Read();


        xSemaphoreTake(Mutex, portMAX_DELAY);
        UART0_SendString("CPU Load is ");
        UART0_SendInteger(ucCPU_Load);
        UART0_SendString("% \r\n");
        xSemaphoreGive(Mutex);

        vTaskDelayUntil(&xLastWakeTime, (500/portTICK_PERIOD_MS));
    }
}

TaskHandle_t    PassengerButtonHandlerHandle;
TaskHandle_t    Heating_level_LOWHandle;
TaskHandle_t    DriverButtonHandleHandle;
TaskHandle_t    Heating_level_MEDUIMHandle;
TaskHandle_t    Heating_level_HIGHHandle;
TaskHandle_t    Temperature_TaskHandle;
TaskHandle_t    vRunTimeMeasurementsTaskHandle;



int main(void)
{
    Hardware_init();

    Mutex = xSemaphoreCreateMutex();
    xEventGroup = xEventGroupCreate();

    if(xEventGroup != NULL&&Mutex!=NULL) {



        xTaskCreate(PassengerButtonHandler, "LED Task", configMINIMAL_STACK_SIZE, NULL, 2, &PassengerButtonHandlerHandle);
        xTaskCreate(Heating_level_LOW, "vLED Task", configMINIMAL_STACK_SIZE, NULL, 2, &Heating_level_LOWHandle);
        xTaskCreate(DriverButtonHandle, "DriverButtonHandle Task", configMINIMAL_STACK_SIZE, NULL, 2, &DriverButtonHandleHandle);
        xTaskCreate(Heating_level_MEDUIM, "DriverButtonHandle Task", configMINIMAL_STACK_SIZE, NULL, 2, &Heating_level_MEDUIMHandle);
        xTaskCreate(Heating_level_HIGH, "DriverButtonHandle Task", configMINIMAL_STACK_SIZE, NULL, 2    , &Heating_level_HIGHHandle);
        xTaskCreate(Temperature_Task, "DriverButtonHandle Task", configMINIMAL_STACK_SIZE, NULL, 3, &Temperature_TaskHandle);
        xTaskCreate(vRunTimeMeasurementsTask, "vRunTimeMeasurementsTask Task", configMINIMAL_STACK_SIZE, NULL, 1, &Temperature_TaskHandle);

        vTaskSetApplicationTaskTag( PassengerButtonHandlerHandle, ( TaskHookFunction_t ) 1 );
        vTaskSetApplicationTaskTag( Heating_level_LOWHandle, ( TaskHookFunction_t ) 2 );
        vTaskSetApplicationTaskTag( DriverButtonHandleHandle, ( TaskHookFunction_t ) 3 );
        vTaskSetApplicationTaskTag( Heating_level_MEDUIMHandle, ( TaskHookFunction_t ) 4 );
        vTaskSetApplicationTaskTag( Heating_level_HIGHHandle, ( TaskHookFunction_t ) 5 );
        vTaskSetApplicationTaskTag( Temperature_TaskHandle, ( TaskHookFunction_t ) 6 );
        vTaskSetApplicationTaskTag( vRunTimeMeasurementsTaskHandle, ( TaskHookFunction_t ) 7 );

        vTaskStartScheduler();
    }

    // Loop forever (in case the scheduler returns)
    while (1) {}

    return 0;
}
void Hardware_init(){
    ADC_init();
    GPIO_ButtonsLedsInit();
    UART0_Init();
}
