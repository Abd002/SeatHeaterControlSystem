/**********************************************************************************************
 *
 * Module: GPIO
 *
 * File Name: GPIO.c
 *
 * Description: Source file for the TM4C123GH6PM DIO driver for TivaC Built-in Buttons and LEDs
 *
 * Author: Edges for Training Team
 *
 ***********************************************************************************************/
#include "gpio.h"
#include "tm4c123gh6pm_registers.h"

void GPIO_ButtonsLedsInit(void)
{
    /*
     * PF0 --> SW2
     * PF1 --> Red LED
     * PF2 --> Blue LED
     * PF3 --> Green LED
     * PF4 --> SW1
     */

    /* Enable clock for PORTF and wait for clock to start */
    SYSCTL_RCGCGPIO_REG |= 0x20;
    while(!(SYSCTL_PRGPIO_REG & 0x20));

    GPIO_PORTF_LOCK_REG   = 0x4C4F434B;                       /* Unlock the GPIO_PORTF_CR_REG */
    GPIO_PORTF_CR_REG    |= (1<<0);                           /* Enable changes on PF0 */
    GPIO_PORTF_AMSEL_REG &= 0xE0;                             /* Disable Analog on PF0, PF1, PF2, PF3 and PF4 */
    GPIO_PORTF_PCTL_REG  &= 0xFFF00000;                       /* Clear PMCx bits for PF0, PF1, PF2, PF3 and PF4 to use it as GPIO pins */
    GPIO_PORTF_DIR_REG   &= ~(1<<0) & ~(1<<4);                /* Configure PF0 & PF4 as input pins */
    GPIO_PORTF_DIR_REG   |= ((1<<1) | (1<<2) | (1<<3));       /* Configure PF1, PF2 & PF3 as output pins */
    GPIO_PORTF_AFSEL_REG &= 0xE0;                             /* Disable alternative function on PF0, PF1, PF2, PF3 and PF4 */
    GPIO_PORTF_PUR_REG   |= ((1<<0)|(1<<4));                  /* Enable pull-up on PF0 & PF4 */
    GPIO_PORTF_DEN_REG   |= 0x1F;                             /* Enable Digital I/O on PF0, PF1, PF2, PF3 and PF4 */
    GPIO_PORTF_DATA_REG  &= ~(1<<1) & ~(1<<2) & ~(1<<3);      /* Clear bits 1, 2 & 3 in Data register to turn off the LEDs */

    GPIO_PORTF_LOCK_REG = 0x4C4F434B;  // Unlock Port F
    GPIO_PORTF_CR_REG |= 0xE0;            // Allow changes to PF5, PF6, and PF7
    GPIO_PORTF_LOCK_REG = 0;              // Lock Port F again
    GPIO_PORTF_DIR_REG |= 0xE0;           // Set PF5, PF6, PF7 as output
    GPIO_PORTF_DEN_REG |= 0xE0;           // Enable digital function for PF5, PF6, PF7
    GPIO_PORTF_DATA_REG &= ~0xE0;         // Set PF5, PF6, PF7 to low (LEDs off)
}

void GPIO_DriverRedLedOn(void)
{
    GPIO_PORTF_DATA_REG |= (1<<1);  /* Red LED ON */
}

void GPIO_DriverBlueLedOn(void)
{
    GPIO_PORTF_DATA_REG |= (1<<2);  /* Blue LED ON */
}

void GPIO_DriverGreenLedOn(void)
{
    GPIO_PORTF_DATA_REG |= (1<<3);  /* Green LED ON */
}

void GPIO_DriverRedLedOff(void)
{
    GPIO_PORTF_DATA_REG &= ~(1<<1);  /* Red LED OFF */
}

void GPIO_DriverBlueLedOff(void)
{
    GPIO_PORTF_DATA_REG &= ~(1<<2);  /* Blue LED OFF */
}

void GPIO_DriverGreenLedOff(void)
{
    GPIO_PORTF_DATA_REG &= ~(1<<3);  /* Green LED OFF */
}


uint8 GPIO_DriverSW1GetState(void)
{
    return ((GPIO_PORTF_DATA_REG >> 4) & 0x01);
}

uint8 GPIO_PassengerSW2GetState(void)
{
    return ((GPIO_PORTF_DATA_REG >> 0) & 0x01);
}





void GPIO_PassengerRedLedOn(void) {
    GPIO_PORTF_DATA_REG |= (1 << 5);      // Set PF5 to high
}
// Function to turn off LED connected to PF5
void GPIO_PassengerRedLedOff(void) {
    GPIO_PORTF_DATA_REG &= ~(1 << 5);     // Set PF5 to low
}

// Function to turn on LED connected to PF6
void GPIO_PassengerBlueLedOn(void) {
    GPIO_PORTF_DATA_REG |= (1 << 6);      // Set PF6 to high
}

// Function to turn off LED connected to PF6
void GPIO_PassengerBlueLedOff(void) {
    GPIO_PORTF_DATA_REG &= ~(1 << 6);     // Set PF6 to low
}

// Function to turn on LED connected to PF7
void GPIO_PassengerGreenLedOn(void) {
    GPIO_PORTF_DATA_REG |= (1 << 7);      // Set PF7 to high
}

// Function to turn off LED connected to PF7
void GPIO_PassengerGreenLedOff(void) {
    GPIO_PORTF_DATA_REG &= ~(1 << 7);     // Set PF7 to low
}
