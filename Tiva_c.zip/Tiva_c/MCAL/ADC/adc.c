/*
 * adc.c
 *
 *  Created on: Aug 15, 2024
 *      Author: AbdElRahman Khalifa
 */



#include "adc.h"
#include"tm4c123gh6pm_registers.h"

#define RCGCADC  (*((volatile uint32*) (0x400FE000+0x638)))

/*
AIN0 6 PE3 I Analog Analog-to-digital converter input 0.
AIN1 7 PE2 I Analog Analog-to-digital converter input 1.
AIN2 8 PE1 I Analog Analog-to-digital converter input 2.
AIN3 9 PE0 I Analog Analog-to-digital converter input 3.
AIN4 64 PD3 I Analog Analog-to-digital converter input 4.
AIN5 63 PD2 I Analog Analog-to-digital converter input 5.
AIN6 62 PD1 I Analog Analog-to-digital converter input 6.
AIN7 61 PD0 I Analog Analog-to-digital converter input 7.
AIN8 60 PE5 I Analog Analog-to-digital converter input 8.
AIN9 59 PE4 I Analog Analog-to-digital converter input 9.
AIN10 58 PB4 I Analog Analog-to-digital converter input 10.
AIN11 57 PB5 I Analog Analog-to-digital converter input 11.
 */
#define ADC0_ACTSS          (*((volatile uint32 *)0x40038000))
#define ADC0_EMUX          (*((volatile uint32 *)0x40038014))
#define ADC0_SSMUX2         (*((volatile uint32 *)0x400380A0))
#define ADC0_SSMUX3         (*((volatile uint32 *)0x400380A4))
#define ADC0_SSCTL2         (*((volatile uint32 *)0x400380A8))
#define ADC0_SSCTL3         (*((volatile uint32 *)0x400380AC))
#define ADC0_IM             (*((volatile uint32 *)0x40038008))
#define ADC0_ISC            (*((volatile uint32 *)0x4003800C))
#define ADC0_RIS            (*((volatile uint32 *)0x40038004))
#define ADC0_SSFIFO2       (*((volatile uint32 *)0x400380A8))
#define ADC0_SSFIFO3        (*((volatile uint32 *)0x400380A4))
#define ADC0_PSSI           (*((volatile uint32 *)0x40038028))


void ADC_init(void){
    RCGCADC=3;
    //enable port B
    SYSCTL_RCGCGPIO_REG |= (1<<1);
    while(!(SYSCTL_PRGPIO_REG & (1<<1)));

    //use PB4 and PB5
    GPIO_PORTB_DIR_REG &= ~((1<<4)|(1<<5));
    GPIO_PORTB_AFSEL_REG |= (1<<4)|(1<<5);

    GPIO_PORTB_DEN_REG &= ~((1<<4)|(1<<5));

    GPIO_PORTB_AMSEL_REG |=(1<<4)|(1<<5);


    // 3. Configure ADC0 Sequencer 3 for PB4
    ADC0_ACTSS &= ~0x08;
    ADC0_EMUX &= ~0xF000;
    ADC0_SSMUX3 = 0x000A;
    ADC0_SSCTL3 = 0x0006;
    ADC0_ACTSS |= 0x08;

    // 4. Configure ADC0 Sequencer 2 for PB5
    ADC0_ACTSS &= ~0x04;
    ADC0_EMUX &= ~0x0F00;
    ADC0_SSMUX2 = 0x000B;
    ADC0_SSCTL2 = 0x0006;
    ADC0_ACTSS |= 0x04;
}

uint32 adc_read_PB4(void) {
    ADC0_PSSI = 0x08;
    while ((ADC0_RIS & 0x08) == 0);
    uint32 result = ADC0_SSFIFO3 & 0xFFF;
    ADC0_ISC = 0x08;
    return result;
}

uint32 adc_read_PB5(void) {
    ADC0_PSSI = 0x04;
    while ((ADC0_RIS & 0x04) == 0);
    uint32 result = ADC0_SSFIFO2 & 0xFFF;
    ADC0_ISC = 0x04;
    return result;
}


