/*
 * ADC.h
 *
 *  Created on: Aug 15, 2024
 *      Author: AbdElRahman Khalifa
 */

#ifndef MCAL_ADC_ADC_H_
#define MCAL_ADC_ADC_H_


#include "std_types.h"

void ADC_init(void);
void ADC_readChannel(void);
uint32 adc_read_PB4(void);
uint32 adc_read_PB5(void);

#endif /* MCAL_ADC_ADC_H_ */
