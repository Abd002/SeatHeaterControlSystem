/*
 * lm35.h
 *
 *  Created on: Aug 16, 2024
 *      Author: AbdElRahman Khalifa
 */

#ifndef MCAL_LM35_LM35_H_
#define MCAL_LM35_LM35_H_


#include "std_types.h"
#include "adc.h"

float lm35_get_temperature_PB4(void);

float lm35_get_temperature_PB5(void);

#endif /* MCAL_LM35_LM35_H_ */
