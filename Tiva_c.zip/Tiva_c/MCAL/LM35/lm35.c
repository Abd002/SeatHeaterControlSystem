/*
 * lm35.c
 *
 *  Created on: Aug 16, 2024
 *      Author: AbdElRahman Khalifa
 */


#include"lm35.h"
//(assuming 3.3V Vref)
float lm35_get_temperature_PB4(void) {
    uint32 adc_value = adc_read_PB4();
    float voltage = (adc_value * 3.3) / 4096.0;
    float temperature = voltage * 100.0;
    return temperature;
}

float lm35_get_temperature_PB5(void) {
    uint32 adc_value = adc_read_PB5();
    float voltage = (adc_value * 3.3) / 4096.0;
    float temperature = voltage * 100.0;
    return temperature;
}
